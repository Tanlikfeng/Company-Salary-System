
public class BankAccount {
	private int ID;
	private double balance;
	
	//constructor
	BankAccount(int ID, double balance){
		this.ID = ID;
		this.balance = balance;
	}
	
	//accessor
	public int getID() {
		return ID;
	}
	
	//accessor
	public double getBalance() {
		return balance;
	}
	
	//mutator
	public void setID(int ID) {
		this.ID = ID;
	}
	
	//mutator
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public void deposit(double amount) {
		balance += amount;
	}
	
	public void withdraw(double amount) {
		if(balance > amount) {
			balance -= amount;
		}
		else {
			System.out.printf("Your accocunt does not have enough money.\n");
		}
	}
}
