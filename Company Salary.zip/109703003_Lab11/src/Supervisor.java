import java.util.ArrayList;

public class Supervisor extends Employee{
	
	ArrayList<Employee> subordinates = new ArrayList<Employee>();
	
	//constructor
	Supervisor(int ID, String name, BankAccount account, String department, int baseSalary, int sales, ArrayList<Employee>subordinates){
		super(ID,name,account,department,baseSalary,sales);
		this.subordinates = subordinates;
		int count=0;
		for(Employee i : this.subordinates) {
			count += i.getSales();
		}
		setSales(this.getSales() + count);
	}
}