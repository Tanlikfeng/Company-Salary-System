
public class Employee {
	private int ID; 
	private double baseSalary;
	private double totalSalary;
	private int sales;
	private String name;
	private String department;
	private BankAccount account;
	
	//constructor
	Employee(int ID, String name, BankAccount account, String department, int baseSalary, int sales){
		this.ID = ID;
		this.name = name;
		this.account = account;
		this.department = department;
		this.baseSalary = baseSalary;
		this.sales = sales;
		this.totalSalary = 0;
	}
	
	//accessor
	public String getDepartment() {
		return department;
	}
	
	//accessor
	public int getSales() {
		return sales;
	}
	
	//accessor
	public double getTotalSalary() {
		return totalSalary;
	}
	
	//mutator
	public void setSales(int sales) {
		this.sales = sales;
	}
	
	public void monthEnd() {
		double taxRate = 0.03;
		int salesBonus = 500;
		double monthlySalary = (baseSalary + (sales * salesBonus)) * (1 - taxRate);
		account.deposit(monthlySalary);
		totalSalary = monthlySalary;
	}
	
	//accessor
	public String getInfo() {
		return String.format("ID: %d\nNames: %s\nDepartment: %s\nTotal sales: %d\nTotal salary: %.1f\nAccount amount: %.1f",this.ID,this.name,this.department,this.sales,this.totalSalary, account.getBalance());
	}
}
